from typing import Final
from flask import Flask, render_template, jsonify, request
import db
import pandas as pd
import re

app = Flask(__name__) 


## URL 별로 함수명이 같거나, 
## route('/') 등의 주소가 같으면 안됩니다. 

# 시작페이지
@app.route('/') 
def main(): 
    return render_template('01_main_page.html') 

#계절 선택 페이지
@app.route('/season_page') 
def season_page(): 
    return render_template('02_season_page.html') 

#재료 선택 페이지
#앞에서 사용자가 선택한 계절정보를 받아오면 해당 계절 재료의 DB를 받아옵니다.
#사용자가 재료를 선택하면 코사인 유사도를 통해 유사한 재료를 사용한 레시피를 받아옵니다.
@app.route('/ingredient_page/<season>', methods=['GET']) 
def ingredient_page(season):
    #SELECT ingredient FROM SEASON WHERE SEASON=='Autumn'
    sql_text="SELECT ingredient FROM SEASON WHERE SEASON=='"+season+"';"
    country_list = sorted(db.get_country_list(sql_text))
    if season=='Autumn':
        season='가을 '+season
    if season=='Spring':
        season='봄 '+season
    if season=='Summer':
        season='여름 '+season
    if season=='Winter':
        season='겨울 '+season
    return render_template('03_ingredient_page.html', season_state=season, country_list=country_list) 

#조리법 선택 페이지
@app.route('/how_page', methods=['GET']) 
def how_page():
    if request.method =='GET':
        data=request.values.getlist('chk[]')
        print(data)

    Final_data=db.get_recommendations(data)
    #print(Final_data)
    return render_template('04_how_page.html', data=data)     

#난이도 선택 페이지
@app.route('/level_page/<search>') 
def level_page(search): 
    print(search)
    how=search
    #SELECT title FROM recipeinfo where id==1
    return render_template('05_level_page.html', how=how)  

# 조리법과 난이도를 기준으로 가장 유사한 상위 TOP 레시피를 보여줍니다.
@app.route('/search_page/<search>') 
def search_page(search):
    print(search)
    user_how=re.split('&', search)[0]
    user_level=re.split('&', search)[1]

    if user_how=='None' and  user_level != 'None':
        sql_text="SELECT NUM FROM SIMILAR WHERE LEVEL=='"+user_level+"';"
        top_ID = db.get_country_list(sql_text)[:3]
    if user_how!='None' and  user_level == 'None':
        sql_text="SELECT NUM FROM SIMILAR WHERE HOW=='"+user_how+"';"
        top_ID = db.get_country_list(sql_text)[:3]
    if user_how=='None' and  user_level == 'None':
        sql_text="SELECT NUM FROM SIMILAR;"
        top_ID = db.get_country_list(sql_text)[:3]
    if user_how!='None' and  user_level != 'None':
        sql_text="SELECT NUM FROM SIMILAR WHERE HOW=='"+user_how+"' and LEVEL=='"+user_level+"';"
        top_ID = db.get_country_list(sql_text)[:3]

    print(top_ID)

    top_TITLE=[]
    top_PIC=[]

    for i in top_ID:
        sql_text="SELECT TITLE FROM recipeinfo WHERE NUM=='"+i+"';"
        top_TITLE.append(db.get_country_list(sql_text)[0])
        sql_text="SELECT PICTURE FROM recipeinfo WHERE NUM=='"+i+"';"
        top_PIC.append(db.get_country_list(sql_text)[0])

    #sql_text="SELECT TITLE FROM recipeinfo WHERE HOW=='"+user_how+"' &LEVEL=='"+user_level+"';"
    #top_title = db.get_country_list(sql_text)

    #sql_text="SELECT PIC FROM recipeinfo WHERE HOW=='"+user_how+"' &LEVEL=='"+user_level+"';"
    #top_pic = db.get_country_list(sql_text)

    return render_template('06_search_page.html', top_ID=top_ID, top_TITLE=top_TITLE, top_PIC=top_PIC)  

# 결과가 없을 때 페이지 입니다.
@app.route('/recipe_page/') 
def no_result():
    return render_template('08_no_result.html')

# 사용자가 선택한 최종 레시피를 상세하게 보여줍니다.
@app.route('/recipe_page/<top_ID>') 
def recipe_page(top_ID):

    print(top_ID)

    sql_text="SELECT TITLE FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    top_TITLE=db.get_country_list(sql_text)[0]

    sql_text="SELECT PICTURE FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    top_PIC=db.get_country_list(sql_text)[0]

    sql_text="SELECT MAIN_INGREDIENT FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    top_main_ingredient=db.get_country_list(sql_text)[0]

    sql_text="SELECT SUB_INGREDIENT FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    top_sub_ingredient=db.get_country_list(sql_text)[0]

    sql_text="SELECT HOW FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    top_how=db.get_country_list(sql_text)[0]

    #sql_text="SELECT ALL_RECIPE FROM recipeinfo WHERE NUM=='"+top_ID+"';"
    #top_recipe=db.get_country_list(sql_text)[0].split('\n')

    top_recipe=[]

    for i in range(1,26):
        sql_text="SELECT RECIPE"+str(i)+" FROM recipeinfo WHERE NUM=='"+top_ID+"';"
        for x in db.get_country_list(sql_text):
            if  x != 'null':
                top_recipe.append(db.get_country_list(sql_text)[0])


    return render_template('07_recipe_page.html', top_TITLE=top_TITLE, top_PIC=top_PIC, top_main_ingredient=top_main_ingredient, top_sub_ingredient=top_sub_ingredient, top_how=top_how, top_recipe=top_recipe)

if __name__=='__main__':
     app.run()








